// il2cpp structure helpers. Layout constants are Il2CppClass from il2cpp.h of the dump (64-bit, Unity 2021.2+).
#pragma once
#include "mem.h"
#include "offsets.h"
#include <functional>

namespace il2 {
constexpr uint32_t K_NAME = 0x10, K_NS = 0x18, K_SELF = 0x78, K_STATICS = 0xB8;   // Il2CppClass
constexpr uint32_t LIST_ITEMS = 0x10, LIST_SIZE = 0x18;                           // List<T>
constexpr uint32_t ARR_LEN = 0x18, ARR_DATA = 0x20;                               // T[]
constexpr uint32_t STR_LEN = 0x10, STR_CHARS = 0x14;                              // System.String
}

class Il2 {
public:
    Il2(IMem& m, uint64_t base) : m_(m), base_(base) {}
    // Il2CppClass* for a class: TypeInfo slot from the dump first, then name scan if the slot is empty/stale.
    uint64_t klass(const ClassRef& c);
    uint64_t statics(uint64_t k) { return k ? rdp(m_, k + il2::K_STATICS) : 0; }
    std::string cstr(uint64_t a, size_t max = 96);
    std::string str(uint64_t s, size_t maxchars = 31);      // System.String -> ascii ('?' for non-ascii)
    // all 8-aligned addresses in rw anon memory holding `klass` as first word and passing `accept`
    std::vector<uint64_t> find_instances(uint64_t klass, const std::function<bool(uint64_t)>& accept);
    bool klass_ok(uint64_t k, const ClassRef& c);
    // List<T> -> (items ptr, size); false if implausible
    bool list(uint64_t l, uint64_t& items, uint32_t& size, uint32_t maxsize = 4096);
private:
    uint64_t scan_klass(const ClassRef& c);
    IMem& m_;
    uint64_t base_;
};
