// CounterFlame state reader: one call = one consistent-enough snapshot for the ESP.
#pragma once
#include "il2cpp.h"
#include "vmath.h"
#include <string>
#include <vector>

struct PlayerInfo {
    int actor = 0;
    Vec3 pos;                 // feet, world
    Vec3 vel;
    float yaw = 0;            // degrees, Unity convention (0 = +Z, clockwise from above)
    bool local = false, dead = false, crouch = false;
    int hp = 100;
    uint8_t team = 0;         // 0 none, 1 CT, 2 T, 3 spec (LifeState.Team*)
    char name[32] = {0};
};

struct Snapshot {
    bool valid = false;       // camera + player list readable
    Cam cam;
    bool haveLocal = false;
    int localActor = 0;
    uint8_t localTeam = 0;
    bool lifeOk = false;      // hp/team table found
    std::vector<PlayerInfo> players;
};

class Game {
public:
    Game(IMem& m, uint64_t il2cppBase) : m_(m), il_(m, il2cppBase) {}
    bool resolve();                 // class pointers; false until the game reached a state where they exist
    bool update(Snapshot& s);
    const char* status() const { return status_; }
private:
    bool find_life();
    IMem& m_;
    Il2 il_;
    uint64_t kCull_ = 0, kFps_ = 0, kLife_ = 0;
    uint64_t cullStatics_ = 0, fpsStatics_ = 0;
    uint64_t life_ = 0;             // LifeState instance
    double nextLifeScan_ = 0;
    const char* status_ = "init";
};
