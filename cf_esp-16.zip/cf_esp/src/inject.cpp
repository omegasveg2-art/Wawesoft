#include "inject.h"
#include <algorithm>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <string>
#include <sys/ioctl.h>
#include <unistd.h>

static bool has_bit(const unsigned long* a, int b) { return a[b / (8 * sizeof(long))] & (1ul << (b % (8 * sizeof(long)))); }

static bool make_uinput(int& out) {
    const char* paths[] = {"/dev/uinput", "/dev/input/uinput", "/dev/misc/uinput"};
    int fd = -1;
    for (const char* p : paths) { fd = open(p, O_WRONLY | O_NONBLOCK); if (fd >= 0) break; }
    if (fd < 0) return false;
    bool ok = ioctl(fd, UI_SET_EVBIT, EV_KEY) == 0 && ioctl(fd, UI_SET_EVBIT, EV_ABS) == 0 && ioctl(fd, UI_SET_EVBIT, EV_SYN) == 0;
    ok = ok && ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH) == 0 && ioctl(fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT) == 0;
    const int axes[] = {ABS_MT_SLOT, ABS_MT_TRACKING_ID, ABS_MT_POSITION_X, ABS_MT_POSITION_Y, ABS_MT_PRESSURE, ABS_MT_TOUCH_MAJOR};
    for (int a : axes) ok = ok && ioctl(fd, UI_SET_ABSBIT, a) == 0;
    uinput_user_dev u;
    memset(&u, 0, sizeof u);
    strncpy(u.name, "Wawer Touch", UINPUT_MAX_NAME_SIZE - 1);
    u.id.bustype = BUS_VIRTUAL; u.id.vendor = 0x1a2b; u.id.product = 0x3c4d; u.id.version = 1;
    u.absmin[ABS_MT_SLOT] = 0;        u.absmax[ABS_MT_SLOT] = 9;
    u.absmin[ABS_MT_TRACKING_ID] = 0; u.absmax[ABS_MT_TRACKING_ID] = 65535;
    u.absmin[ABS_MT_POSITION_X] = 0;  u.absmax[ABS_MT_POSITION_X] = 32767;
    u.absmin[ABS_MT_POSITION_Y] = 0;  u.absmax[ABS_MT_POSITION_Y] = 32767;
    u.absmin[ABS_MT_PRESSURE] = 0;    u.absmax[ABS_MT_PRESSURE] = 255;
    u.absmin[ABS_MT_TOUCH_MAJOR] = 0; u.absmax[ABS_MT_TOUCH_MAJOR] = 255;
    ok = ok && write(fd, &u, sizeof u) == (ssize_t)sizeof u && ioctl(fd, UI_DEV_CREATE) == 0;
    if (!ok) { close(fd); return false; }
    usleep(500 * 1000);                    // let InputReader pick the new device up
    out = fd;
    return true;
}

bool Touch::init() {
    if (make_uinput(ufd_)) { minx_ = 0; maxx_ = 32767; miny_ = 0; maxy_ = 32767; slot_ = 0; tid_ = 100; idMax_ = 65535; return true; }
    DIR* d = opendir("/dev/input");
    if (!d) return false;
    while (dirent* e = readdir(d)) {
        if (strncmp(e->d_name, "event", 5)) continue;
        std::string p = std::string("/dev/input/") + e->d_name;
        int fd = open(p.c_str(), O_RDWR | O_NONBLOCK);
        if (fd < 0) continue;
        unsigned long abs[(ABS_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        unsigned long prop[(INPUT_PROP_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        ioctl(fd, EVIOCGBIT(EV_ABS, sizeof abs), abs);
        ioctl(fd, EVIOCGPROP(sizeof prop), prop);
        if (!has_bit(abs, ABS_MT_POSITION_X) || !has_bit(abs, ABS_MT_SLOT) || !has_bit(prop, INPUT_PROP_DIRECT)) { close(fd); continue; }
        input_absinfo ax{}, ay{}, as{}, ai{};
        ioctl(fd, EVIOCGABS(ABS_MT_POSITION_X), &ax);
        ioctl(fd, EVIOCGABS(ABS_MT_POSITION_Y), &ay);
        ioctl(fd, EVIOCGABS(ABS_MT_SLOT), &as);
        ioctl(fd, EVIOCGABS(ABS_MT_TRACKING_ID), &ai);
        fd_ = fd; minx_ = ax.minimum; maxx_ = ax.maximum; miny_ = ay.minimum; maxy_ = ay.maximum;
        slot_ = as.maximum;                       // highest slot: unlikely to collide with real fingers
        idMax_ = ai.maximum > 100 ? ai.maximum : 65535;
        tid_ = 4000;
        break;
    }
    closedir(d);
    return fd_ >= 0;
}

void Touch::emit(int type, int code, int value) {
    input_event ev;
    memset(&ev, 0, sizeof ev);
    ev.type = (unsigned short)type; ev.code = (unsigned short)code; ev.value = value;
    int fd = ufd_ >= 0 ? ufd_ : fd_;
    if (fd >= 0 && write(fd, &ev, sizeof ev) < 0) { /* ignore */ }
}

void Touch::move(float lx, float ly, float W, float H, int rot) {
    if (!ready()) return;
    float Wp = std::min(W, H), Hp = std::max(W, H), px, py;      // physical portrait size in px
    switch (rot) {                                               // inverse of the logical <- panel mapping
        case 1:  px = Wp - ly; py = lx; break;
        case 2:  px = Wp - lx; py = Hp - ly; break;
        case 3:  px = ly;      py = Hp - lx; break;
        default: px = lx;      py = ly;
    }
    px = std::max(0.f, std::min(Wp, px)); py = std::max(0.f, std::min(Hp, py));
    int rx = minx_ + (int)(px / Wp * (maxx_ - minx_)), ry = miny_ + (int)(py / Hp * (maxy_ - miny_));
    emit(EV_ABS, ABS_MT_SLOT, slot_);
    if (!down_) {
        tid_ = tid_ >= idMax_ ? 100 : tid_ + 1;
        emit(EV_ABS, ABS_MT_TRACKING_ID, tid_);
        if (ufd_ >= 0) { emit(EV_ABS, ABS_MT_PRESSURE, 90); emit(EV_ABS, ABS_MT_TOUCH_MAJOR, 12); }
        down_ = true;
    }
    emit(EV_ABS, ABS_MT_POSITION_X, rx);
    emit(EV_ABS, ABS_MT_POSITION_Y, ry);
    if (ufd_ >= 0) emit(EV_KEY, BTN_TOUCH, 1);
    emit(EV_SYN, SYN_REPORT, 0);
}

void Touch::lift() {
    if (!ready() || !down_) return;
    emit(EV_ABS, ABS_MT_SLOT, slot_);
    emit(EV_ABS, ABS_MT_TRACKING_ID, -1);
    if (ufd_ >= 0) emit(EV_KEY, BTN_TOUCH, 0);
    emit(EV_SYN, SYN_REPORT, 0);
    down_ = false;
}

Touch::~Touch() {
    lift();
    if (ufd_ >= 0) { ioctl(ufd_, UI_DEV_DESTROY); close(ufd_); }
    if (fd_ >= 0) close(fd_);
}

bool Keys::init() {
    DIR* d = opendir("/dev/input");
    if (!d) return false;
    while (dirent* e = readdir(d)) {
        if (strncmp(e->d_name, "event", 5)) continue;
        std::string p = std::string("/dev/input/") + e->d_name;
        int fd = open(p.c_str(), O_RDONLY | O_NONBLOCK);
        if (fd < 0) continue;
        unsigned long key[(KEY_MAX + 1) / (8 * sizeof(long)) + 1] = {0};
        ioctl(fd, EVIOCGBIT(EV_KEY, sizeof key), key);
        if (has_bit(key, KEY_VOLUMEDOWN) || has_bit(key, KEY_VOLUMEUP)) fds_.push_back(fd); else close(fd);
    }
    closedir(d);
    return !fds_.empty();
}

void Keys::poll() {
    for (int fd : fds_) {
        input_event ev[32];
        ssize_t n;
        while ((n = read(fd, ev, sizeof ev)) > 0)
            for (size_t i = 0; i < (size_t)n / sizeof(input_event); i++)
                if (ev[i].type == EV_KEY) {
                    if (ev[i].code == KEY_VOLUMEDOWN) dn_[0] = ev[i].value != 0;
                    else if (ev[i].code == KEY_VOLUMEUP) dn_[1] = ev[i].value != 0;
                }
    }
}

bool Keys::down(int code) const { return code == KEY_VOLUMEDOWN ? dn_[0] : code == KEY_VOLUMEUP ? dn_[1] : false; }

void Keys::grab(bool on) {
    if (on == grabbed_) return;
    for (int fd : fds_) ioctl(fd, EVIOCGRAB, on ? 1 : 0);
    grabbed_ = on;
}

Keys::~Keys() { grab(false); for (int fd : fds_) close(fd); }
