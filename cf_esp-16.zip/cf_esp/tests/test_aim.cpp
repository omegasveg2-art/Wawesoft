// g++ -std=c++17 -I../src test_aim.cpp ../src/aim.cpp ../src/game.cpp ../src/il2cpp.cpp ../src/mem.cpp
#include "../src/aim.h"
#include <cstdio>
#include <cassert>
static int fails = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %d: %s\n", __LINE__, #x); fails++; } } while (0)
int main() {
    Snapshot s; s.valid = true; s.cam.pos = {0, 1.6f, 0}; s.cam.fwd = {0, 0, 1}; s.cam.fovY = 70; s.localTeam = 1;
    PlayerInfo e; e.actor = 5; e.team = 2; e.pos = {3, 0, 12}; s.players.push_back(e);
    AimCfg c; c.on = true; c.fovPx = 2000; c.ppd = 10.f; c.leadMs = 0;
    AimOut o = aim_step(s, c, 0);
    CHECK(o.has && o.actor == 5 && o.dyaw > 0);                     // target is to the right
    // apply the full correction as a camera rotation, target must land on screen centre
    float dyaw = o.dyaw, dpitch = o.dpitch;                          // deg
    const float D = 3.14159265f / 180.f;
    float yaw = dyaw * D, pitch = dpitch * D;
    s.cam.fwd = {std::cos(pitch) * std::sin(yaw), std::sin(pitch), std::cos(pitch) * std::cos(yaw)};
    float x, y;
    Vec3 pt = bone_point(e, 0, 0);
    CHECK(w2s(s.cam, pt, c.W, c.H, x, y));
    printf("after full aim step target at %.2f %.2f (centre %.0f %.0f)\n", x, y, c.W / 2, c.H / 2);
    CHECK(std::fabs(x - c.W / 2) < 0.5f && std::fabs(y - c.H / 2) < 0.5f);
    // teammate must be ignored, dead ignored, out-of-fov ignored
    s.cam.fwd = {0, 0, 1}; s.players[0].team = 1; CHECK(!aim_step(s, c, 0).has);
    s.players[0].team = 2; s.players[0].dead = true; CHECK(!aim_step(s, c, 0).has);
    s.players[0].dead = false; c.fovPx = 5; CHECK(!aim_step(s, c, 0).has);
    c.on = false; c.fovPx = 2000; CHECK(!aim_step(s, c, 0).has);
    // bones: legs below body below head
    { PlayerInfo q = e; CHECK(bone_point(q, 0, 0).y > bone_point(q, 1, 0).y && bone_point(q, 1, 0).y > bone_point(q, 2, 0).y); }
    // closed loop: simulate a camera that follows injected px with 2 frames latency and gain 12 px/deg; must converge, no oscillation
    {
        AimCfg k; k.on = true; k.fovPx = 4000; k.ppd = 8.f; k.leadMs = 0; k.maxStep = 80.f; k.smooth = 0.3f;
        Snapshot t = s; t.cam.fwd = {0, 0, 1}; t.players[0].team = 2; t.players[0].dead = false;
        AimCtl ctl; float yaw = 0, pit = 0, qx[3] = {0, 0, 0}, qy[3] = {0, 0, 0}, maxOver = 0;
        Vec3 pt = bone_point(t.players[0], 0, 0);
        float tgtYaw = std::atan2(pt.x, pt.z) * 57.29578f;
        for (int f = 0; f < 120; f++) {
            float cy = std::cos(pit * 0.0174533f);
            t.cam.fwd = {cy * std::sin(yaw * 0.0174533f), std::sin(pit * 0.0174533f), cy * std::cos(yaw * 0.0174533f)};
            ctl.observe(yaw, pit, true);
            AimOut a = aim_step(t, k, 5);
            float dx = 0, dy = 0;
            if (a.has) ctl.step(a, k, f * 0.016, dx, dy);
            qx[2] = qx[1]; qx[1] = qx[0]; qx[0] = dx; qy[2] = qy[1]; qy[1] = qy[0]; qy[0] = dy;
            yaw += qx[2] / 12.f; pit += qy[2] / -12.f;                 // real gain 12 px/deg (guess was 8), Y inverted like the guess
            if (yaw - tgtYaw > maxOver) maxOver = yaw - tgtYaw;
        }
        printf("closed loop: yaw %.2f target %.2f overshoot %.2f deg, ppdX %.1f ppdY %.1f\n", yaw, tgtYaw, maxOver, ctl.ppdX, ctl.ppdY);
        CHECK(std::fabs(yaw - tgtYaw) < 0.3f);
        CHECK(maxOver < 2.0f);
    }
    printf(fails ? "%d FAILED\n" : "aim ok\n", fails);
    return fails != 0;
}
